﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Windows.Forms.DataVisualization.Charting;

namespace chart1_3
{
    public partial class Form1 : Form
    {
        public class datData
        {
            public string wavelength { get; set; }
            public string P { get; set; }
            public string S { get; set; }
        }

        int count = 0; // 데이터 수 count

        List<datData> records = new List<datData>(); 
        public Form1()
        {
            InitializeComponent();
            char[] replace = { ' ', ',', '\t', '\n' };
            string[] lines = File.ReadAllLines("C://Si_new.txt", Encoding.Default);

            foreach (var line in lines)
            {
                string[] splitData = line.Split(replace, StringSplitOptions.RemoveEmptyEntries);
                records.Add(new datData
                {
                    wavelength = splitData[0],
                    P = splitData[1],
                    S = splitData[2]
                });
                count++;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            chart1.Series.Clear();

            chart1.ChartAreas.Add("chart");

            chart1.Series.Add("P편광");
            chart1.Series["P편광"].ChartType = SeriesChartType.Line;
            chart1.Series["P편광"].BorderWidth = 3;

            chart1.Series.Add("S편광");
            chart1.Series["S편광"].ChartType = SeriesChartType.Line;
            chart1.Series["S편광"].BorderWidth = 3;


            for (int i = 1; i < count; i++)
            {
                chart1.Series["P편광"].Points.AddXY(records[i].wavelength, records[i].P);
                chart1.Series["S편광"].Points.AddXY(records[i].wavelength, records[i].S);
            }
        }
    }
}
