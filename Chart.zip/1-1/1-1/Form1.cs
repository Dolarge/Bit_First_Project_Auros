﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace _1_1
{
    public partial class Form1 : Form
    {
        public class datData
        {
            public string wavelength { get; set; }
            public string AOI { get; set; }
            public string Psi { get; set; }
            public string Delta { get; set; }
        }
        public class newdatData
        {
            public string wavelength { get; set; }
            public string AOI { get; set; }
            public string alpha { get; set; }
            public string beta { get; set; }
        }

        int cnt1, cnt2 = 0; // 데이터 수 count

        List<datData> datrecords = new List<datData>();
        List<newdatData> newdatrecords = new List<newdatData>();
        public Form1()
        {
            InitializeComponent();
            char[] replace = { ' ', ',', '\t', '\n' };
            string[] datlines = File.ReadAllLines("C://SiO2_2nm_on_Si.dat", Encoding.Default);
            string[] newlines = File.ReadAllLines("C://SiO2_2nm_on_Si_new.dat", Encoding.Default);

            foreach (var line in datlines)
            {
                string[] splitData = line.Split(replace, StringSplitOptions.RemoveEmptyEntries);
                datrecords.Add(new datData
                {
                    wavelength = splitData[0],
                    AOI = splitData[1],
                    Psi = splitData[2],
                    Delta = splitData[3]
                });
                cnt1++;
            }
            foreach (var line in newlines)
            {
                string[] splitData = line.Split(replace, StringSplitOptions.RemoveEmptyEntries);
                newdatrecords.Add(new newdatData
                {
                    wavelength = splitData[0],
                    AOI = splitData[1],
                    alpha = splitData[2],
                    beta = splitData[3]
                });
                cnt2++;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            chart1.Series.Clear();
            chart2.Series.Clear();

            //chart1.ChartAreas.Add("chart1");
            //chart2.ChartAreas.Add("chart2");

            chart1.Series.Add("Psi");
            chart1.Series.Add("Delta");
            chart1.Series["Psi"].ChartType = SeriesChartType.Line;
            chart1.Series["Delta"].ChartType = SeriesChartType.Line;
            chart1.Series["Psi"].Color = Color.LightPink;
            chart1.Series["Delta"].Color = Color.DarkGreen;
            chart1.Series["Psi"].BorderWidth = 3;
            chart1.Series["Delta"].BorderWidth = 3;

            chart2.Series.Add("alpha");
            chart2.Series.Add("beta");
            chart2.Series["alpha"].ChartType = SeriesChartType.Line;
            chart2.Series["beta"].ChartType = SeriesChartType.Line;
            chart2.Series["alpha"].BorderWidth = 3;
            chart2.Series["beta"].BorderWidth = 3;


            for (int i = 1; i < cnt1; i++)
            {
                chart1.Series["Psi"].Points.AddXY(datrecords[i].wavelength, datrecords[i].Psi);
                chart1.Series["Delta"].Points.AddXY(datrecords[i].wavelength, datrecords[i].Delta);
            }

            for (int i = 1; i < cnt2; i++)
            {
                chart2.Series["alpha"].Points.AddXY(newdatrecords[i].wavelength, newdatrecords[i].alpha);
                chart2.Series["beta"].Points.AddXY(newdatrecords[i].wavelength, newdatrecords[i].beta);
            }
        }
    }
}
