﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace _1_3_65_alpha_beta_3_
{
    public partial class Form1 : Form
    {
        public class DataExp
        {
            public string wavelength { get; set; }
            public string AOI { get; set; }
            public string alpha { get; set; }
            public string beta { get; set; }
        }

        public class DataCal
        {
            public string wavelength { get; set; }
            public string AOI { get; set; }
            public string alpha { get; set; }
            public string beta { get; set; }
        }

        int count1, count2 = 0;
        List<DataExp> records_exp = new List<DataExp>();
        List<DataCal> records_cal = new List<DataCal>();
        public Form1()
        {
            InitializeComponent();

            char[] replace = { ' ', ',', '\t', '\n' };
            string[] lines4085 = File.ReadAllLines("C://SiO2_2nm_on_Si_new.dat", Encoding.Default);
            string[] lines65 = File.ReadAllLines("C://Si_new_65_alpha.txt", Encoding.Default);

            foreach (var line in lines4085)
            {
                string[] splitData = line.Split(replace, StringSplitOptions.RemoveEmptyEntries);
                records_exp.Add(new DataExp
                {
                    wavelength = splitData[0],
                    AOI = splitData[1],
                    alpha = splitData[2],
                    beta = splitData[3]
                });
                count1++;
            }

            foreach (var line in lines65)
            {
                string[] splitData = line.Split(replace, StringSplitOptions.RemoveEmptyEntries);
                records_cal.Add(new DataCal
                {
                    wavelength = splitData[0],
                    AOI = splitData[1],
                    alpha = splitData[2],
                    beta = splitData[3]
                });
                count2++;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            chart1.Series.Clear();


            chart1.Series.Add("alpha");
            chart1.Series["alpha"].ChartType = SeriesChartType.Line;
            chart1.Series["alpha"].BorderWidth = 3;
            chart1.Series["alpha"].Color = Color.DarkOrange;

            chart2.Series.Add("beta");
            chart2.Series["beta"].ChartType = SeriesChartType.Line;
            chart2.Series["beta"].BorderWidth = 3;
            chart2.Series["beta"].Color = Color.CornflowerBlue;


            int aoi = 0;
            double nm = 0.0;
            double alpha_cal, alpha_exp = 0.0;
            double beta_cal, beta_exp = 0.0;
            double a, b = 0.0; // alpha, beta 차이

            for (int i = 1; i < count1; i++)
            {
                aoi = Convert.ToInt32(records_cal[i].AOI);
                nm = Single.Parse(records_cal[i].wavelength);

                alpha_cal = Single.Parse(records_cal[i].alpha);
                alpha_exp = Single.Parse(records_exp[i].alpha);
                beta_cal = Single.Parse(records_cal[i].beta);
                beta_exp = Single.Parse(records_exp[i].beta);

                a = alpha_exp - alpha_cal;
                b = beta_exp - beta_cal;

                chart1.Series["alpha"].Points.AddXY(nm, a);
                chart2.Series["beta"].Points.AddXY(nm, b);
            }
        }
    }
}
