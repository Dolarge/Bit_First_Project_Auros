﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace _1_2_sin
{
    public partial class Form1 : Form
    {
        public class nmData
        {
            public string wavelength { get; set; }
            public string n { get; set; }
            public string k { get; set; }
        }

        public class newData
        {
            public string wavelength { get; set; }
            public string n { get; set; }
            public string k { get; set; }
        }

        int cnt1, cnt2 = 0; // 데이터 수 count

        List<nmData> nmrecords = new List<nmData>();
        List<newData> newrecords = new List<newData>();

        public Form1()
        {
            InitializeComponent();
            char[] replace = { ' ', ',', '\t', '\n' };
            string[] nmlines = File.ReadAllLines("C://SiN.txt", Encoding.Default);
            string[] newlines = File.ReadAllLines("C://SiN_new.txt", Encoding.Default);

            foreach (var line in nmlines)
            {
                string[] splitData = line.Split(replace, StringSplitOptions.RemoveEmptyEntries);
                nmrecords.Add(new nmData
                {
                    wavelength = splitData[0],
                    n = splitData[1],
                    k = splitData[2]
                });
                cnt1++;
            }

            foreach (var line in newlines)
            {
                string[] splitData = line.Split(replace, StringSplitOptions.RemoveEmptyEntries);
                newrecords.Add(new newData
                {
                    wavelength = splitData[0],
                    n = splitData[1],
                    k = splitData[2]
                });
                cnt2++;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            chart1.Series.Clear();
            chart2.Series.Clear();

            chart1.Series.Add("SiN_n");
            chart1.Series.Add("SiN_new_n");
            chart1.Series["SiN_n"].ChartType = SeriesChartType.Line;
            chart1.Series["SiN_new_n"].ChartType = SeriesChartType.Line;
            chart1.Series["SiN_n"].BorderWidth = 3;
            chart1.Series["SiN_new_n"].BorderWidth = 3;
            chart1.Series["SiN_n"].Color = Color.LightBlue;
            chart1.Series["SiN_new_n"].Color = Color.DarkBlue;

            chart2.Series.Add("SiN_k");
            chart2.Series.Add("SiN_new_k");
            chart2.Series["SiN_k"].ChartType = SeriesChartType.Line;
            chart2.Series["SiN_new_k"].ChartType = SeriesChartType.Line;
            chart2.Series["SiN_k"].BorderWidth = 3;
            chart2.Series["SiN_new_k"].BorderWidth = 3;
            chart2.Series["SiN_k"].Color = Color.Orange;
            chart2.Series["SiN_new_k"].Color = Color.DarkGreen;

            double nm1, nm2 = 0.0;

            for (int i = 1; i < cnt1; i++)
            {
                nm1 = Single.Parse(nmrecords[i].wavelength);
                chart1.Series["SiN_n"].Points.AddXY(nm1, nmrecords[i].n);
                chart2.Series["SiN_k"].Points.AddXY(nm1, nmrecords[i].k);
            }

            for (int i = 1; i < cnt2; i++)
            {
                nm2 = Single.Parse(newrecords[i].wavelength);
                chart1.Series["SiN_new_n"].Points.AddXY(nm2, newrecords[i].n);
                chart2.Series["SiN_new_k"].Points.AddXY(nm2, newrecords[i].k);
            }
        }
    }
}
