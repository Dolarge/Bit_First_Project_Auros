﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace _2_1__1__alphabeta
{
    public partial class Form1 : Form
    {
        public class newData
        {
            public string wavelength { get; set; }
            public string AOI { get; set; }
            public string alpha { get; set; }
            public string beta { get; set; }
        }
        public class abData
        {
            public string wavelength { get; set; }
            public string AOI { get; set; }
            public string alpha { get; set; }
            public string beta { get; set; }
        }

        int cnt1, cnt2 = 0;
        List<newData> newrecords = new List<newData>();
        List<abData> abrecords = new List<abData>();
        public Form1()
        {
            InitializeComponent();

            char[] replace = { ' ', ',', '\t', '\n' };
            string[] lines = File.ReadAllLines("C://SiO2_1000nm_on_Si_new.dat", Encoding.Default);
            string[] ablines = File.ReadAllLines("C://SiO2_1000nm_on_Si_new_dolarge.dat", Encoding.Default);

            foreach (var line in lines)
            {
                string[] splitData = line.Split(replace, StringSplitOptions.RemoveEmptyEntries);
                newrecords.Add(new newData
                {
                    wavelength = splitData[0],
                    AOI = splitData[1],
                    alpha = splitData[2],
                    beta = splitData[3]
                });
                cnt1++;
            }

            foreach (var line in lines)
            {
                string[] splitData = line.Split(replace, StringSplitOptions.RemoveEmptyEntries);
                abrecords.Add(new abData
                {
                    wavelength = splitData[0],
                    AOI = splitData[1],
                    alpha = splitData[2],
                    beta = splitData[3]
                });
                cnt2++;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            chart1.Series.Clear();

            chart1.Series.Add("alpha(cal)");
            chart1.Series.Add("beta(cal)");
            chart1.Series["alpha(cal)"].ChartType = SeriesChartType.Line;
            chart1.Series["beta(cal)"].ChartType = SeriesChartType.Line;
            chart1.Series["alpha(cal)"].BorderWidth = 11;
            chart1.Series["beta(cal)"].BorderWidth = 11;
            chart1.Series["alpha(cal)"].Color = Color.Red;
            chart1.Series["beta(cal)"].Color = Color.LightGreen;

            chart1.Series.Add("alpha(exp)");
            chart1.Series.Add("beta(exp)");
            //chart1.Series.Add("MSE = 2.02457479859831E-10");
            chart1.Series["alpha(exp)"].ChartType = SeriesChartType.Line;
            chart1.Series["beta(exp)"].ChartType = SeriesChartType.Line;
            chart1.Series["alpha(exp)"].BorderWidth = 3;
            chart1.Series["beta(exp)"].BorderWidth = 3;
            chart1.Series["alpha(exp)"].Color = Color.Blue;
            chart1.Series["beta(exp)"].Color = Color.DarkViolet;
            //chart1.Series["/*MSE = 2.02457479859831E-10*/"].Color = Color.White;

            double nm1, nm2 = 0.0;

            for (int i = 1; i < cnt1; i++)
            {
                nm1 = Single.Parse(newrecords[i].wavelength);
                chart1.Series["alpha(cal)"].Points.AddXY(nm1, newrecords[i].alpha);
                chart1.Series["beta(cal)"].Points.AddXY(nm1, newrecords[i].beta);
            }

            for (int i = 1; i < cnt2; i++)
            {
                nm2 = Single.Parse(abrecords[i].wavelength);
                chart1.Series["alpha(exp)"].Points.AddXY(nm2, abrecords[i].alpha);
                chart1.Series["beta(exp)"].Points.AddXY(nm2, abrecords[i].beta);
            }
        }
    }
}
