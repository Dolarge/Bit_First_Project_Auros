﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace _1_3_alpha__2_
{
    public partial class Form1 : Form
    {
        public class Data4085
        {
            public string wavelength { get; set; }
            public string AOI { get; set; }
            public string alpha { get; set; }
            public string beta { get; set; }
        }

        int count1, count2 = 0;
        List<Data4085> records4085 = new List<Data4085>();
        List<Data4085> records65 = new List<Data4085>();
        public Form1()
        {
            InitializeComponent();

            char[] replace = { ' ', ',', '\t', '\n' };
            string[] lines = File.ReadAllLines("C://Si_new_40~85_alpha.txt", Encoding.Default);
            string[] lines65 = File.ReadAllLines("C://Si_new_65_alpha.txt", Encoding.Default);

            foreach (var line in lines)
            {
                string[] splitData = line.Split(replace, StringSplitOptions.RemoveEmptyEntries);
                records4085.Add(new Data4085
                {
                    wavelength = splitData[0],
                    AOI = splitData[1],
                    alpha = splitData[2],
                    beta = splitData[3]
                });
                count1++;
            }
            foreach (var line in lines65)
            {
                string[] splitData = line.Split(replace, StringSplitOptions.RemoveEmptyEntries);
                records65.Add(new Data4085
                {
                    wavelength = splitData[0],
                    AOI = splitData[1],
                    alpha = splitData[2],
                    beta = splitData[3]
                });
                count2++;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            chart1.Series.Clear();

            chart1.Series.Add("alpha(40)");
            chart1.Series["alpha(40)"].ChartType = SeriesChartType.Line;
            chart1.Series["alpha(40)"].BorderWidth = 5;
            chart1.Series["alpha(40)"].Color = Color.MistyRose;

            chart1.Series.Add("alpha(45)");
            chart1.Series["alpha(45)"].ChartType = SeriesChartType.Line;
            chart1.Series["alpha(45)"].BorderWidth = 5;
            chart1.Series["alpha(45)"].Color = Color.Pink;

            chart1.Series.Add("alpha(50)");
            chart1.Series["alpha(50)"].ChartType = SeriesChartType.Line;
            chart1.Series["alpha(50)"].BorderWidth = 5;
            chart1.Series["alpha(50)"].Color = Color.Thistle;

            chart1.Series.Add("alpha(55)");
            chart1.Series["alpha(55)"].ChartType = SeriesChartType.Line;
            chart1.Series["alpha(55)"].BorderWidth = 5;
            chart1.Series["alpha(55)"].Color = Color.LightCoral;

            chart1.Series.Add("alpha(60)");
            chart1.Series["alpha(60)"].ChartType = SeriesChartType.Line;
            chart1.Series["alpha(60)"].BorderWidth = 5;
            chart1.Series["alpha(60)"].Color = Color.Violet;

            chart1.Series.Add("alpha(65)");
            chart1.Series["alpha(65)"].ChartType = SeriesChartType.Line;
            chart1.Series["alpha(65)"].BorderWidth = 5;
            chart1.Series["alpha(65)"].Color = Color.HotPink;

            chart1.Series.Add("alpha(70)");
            chart1.Series["alpha(70)"].ChartType = SeriesChartType.Line;
            chart1.Series["alpha(70)"].BorderWidth = 5;
            chart1.Series["alpha(70)"].Color = Color.PaleVioletRed;

            chart1.Series.Add("alpha(75)");
            chart1.Series["alpha(75)"].ChartType = SeriesChartType.Line;
            chart1.Series["alpha(75)"].BorderWidth = 5;
            chart1.Series["alpha(75)"].Color = Color.DeepPink;

            chart1.Series.Add("alpha(80)");
            chart1.Series["alpha(80)"].ChartType = SeriesChartType.Line;
            chart1.Series["alpha(80)"].BorderWidth = 5;
            chart1.Series["alpha(80)"].Color = Color.Crimson;

            chart1.Series.Add("alpha(85)");
            chart1.Series["alpha(85)"].ChartType = SeriesChartType.Line;
            chart1.Series["alpha(85)"].BorderWidth = 5;
            chart1.Series["alpha(85)"].Color = Color.MediumVioletRed;




            chart1.Series.Add("beta(40)");
            chart1.Series["beta(40)"].ChartType = SeriesChartType.Line;
            chart1.Series["beta(40)"].BorderWidth = 5;
            chart1.Series["beta(40)"].Color = Color.PowderBlue;

            chart1.Series.Add("beta(45)");
            chart1.Series["beta(45)"].ChartType = SeriesChartType.Line;
            chart1.Series["beta(45)"].BorderWidth = 5;
            chart1.Series["beta(45)"].Color = Color.SkyBlue;

            chart1.Series.Add("beta(50)");
            chart1.Series["beta(50)"].ChartType = SeriesChartType.Line;
            chart1.Series["beta(50)"].BorderWidth = 5;
            chart1.Series["beta(50)"].Color = Color.MediumAquamarine;

            chart1.Series.Add("beta(55)");
            chart1.Series["beta(55)"].ChartType = SeriesChartType.Line;
            chart1.Series["beta(55)"].BorderWidth = 5;
            chart1.Series["beta(55)"].Color = Color.DeepSkyBlue;

            chart1.Series.Add("beta(60)");
            chart1.Series["beta(60)"].ChartType = SeriesChartType.Line;
            chart1.Series["beta(60)"].BorderWidth = 5;
            chart1.Series["beta(60)"].Color = Color.CornflowerBlue;

            chart1.Series.Add("beta(65)");
            chart1.Series["beta(65)"].ChartType = SeriesChartType.Line;
            chart1.Series["beta(65)"].BorderWidth = 5;
            chart1.Series["beta(65)"].Color = Color.DodgerBlue;

            chart1.Series.Add("beta(70)");
            chart1.Series["beta(70)"].ChartType = SeriesChartType.Line;
            chart1.Series["beta(70)"].BorderWidth = 5;
            chart1.Series["beta(70)"].Color = Color.RoyalBlue;

            chart1.Series.Add("beta(75)");
            chart1.Series["beta(75)"].ChartType = SeriesChartType.Line;
            chart1.Series["beta(75)"].BorderWidth = 5;
            chart1.Series["beta(75)"].Color = Color.SlateBlue;

            chart1.Series.Add("beta(80)");
            chart1.Series["beta(80)"].ChartType = SeriesChartType.Line;
            chart1.Series["beta(80)"].BorderWidth = 5;
            chart1.Series["beta(80)"].Color = Color.GreenYellow;

            chart1.Series.Add("beta(85)");
            chart1.Series["beta(85)"].ChartType = SeriesChartType.Line;
            chart1.Series["beta(85)"].BorderWidth = 5;
            chart1.Series["beta(85)"].Color = Color.GreenYellow;

            chart1.Series.Add("alpha(측정)");
            chart1.Series["alpha(측정)"].ChartType = SeriesChartType.Line;
            chart1.Series["alpha(측정)"].BorderWidth = 3;
            chart1.Series["alpha(측정)"].Color = Color.DarkSlateBlue;

            chart1.Series.Add("beta(측정)");
            chart1.Series["beta(측정)"].ChartType = SeriesChartType.Line;
            chart1.Series["beta(측정)"].BorderWidth = 3;
            chart1.Series["beta(측정)"].Color = Color.Navy;

            double nm_4085, alpha_4085, beta_4085 = 0;

            int aoi_4085 = 0;

            for (int i = 1; i < count1; i++)
            {
                nm_4085 = Single.Parse(records4085[i].wavelength);
                aoi_4085 = Convert.ToInt32(records4085[i].AOI);
                alpha_4085 = Single.Parse(records4085[i].alpha);
                beta_4085 = Single.Parse(records4085[i].beta);

                switch (aoi_4085)
                {
                    case 40:
                        chart1.Series["alpha(40)"].Points.AddXY(nm_4085, alpha_4085);
                        chart1.Series["beta(40)"].Points.AddXY(nm_4085, beta_4085);
                        break;
                    case 45:
                        chart1.Series["alpha(45)"].Points.AddXY(nm_4085, alpha_4085);
                        chart1.Series["beta(45)"].Points.AddXY(nm_4085, beta_4085);
                        break;
                    case 50:
                        chart1.Series["alpha(50)"].Points.AddXY(nm_4085, alpha_4085);
                        chart1.Series["beta(50)"].Points.AddXY(nm_4085, beta_4085);
                        break;
                    case 55:
                        chart1.Series["alpha(55)"].Points.AddXY(nm_4085, alpha_4085);
                        chart1.Series["beta(55)"].Points.AddXY(nm_4085, beta_4085);
                        break;
                    case 60:
                        chart1.Series["alpha(60)"].Points.AddXY(nm_4085, alpha_4085);
                        chart1.Series["beta(60)"].Points.AddXY(nm_4085, beta_4085);
                        break;
                    case 65:
                        chart1.Series["alpha(65)"].Points.AddXY(nm_4085, alpha_4085);
                        chart1.Series["beta(65)"].Points.AddXY(nm_4085, beta_4085);
                        break;
                    case 70:
                        chart1.Series["alpha(70)"].Points.AddXY(nm_4085, alpha_4085);
                        chart1.Series["beta(70)"].Points.AddXY(nm_4085, beta_4085);
                        break;
                    case 75:
                        chart1.Series["alpha(75)"].Points.AddXY(nm_4085, alpha_4085);
                        chart1.Series["beta(75)"].Points.AddXY(nm_4085, beta_4085);
                        break;
                    case 80:
                        chart1.Series["alpha(80)"].Points.AddXY(nm_4085, alpha_4085);
                        chart1.Series["beta(80)"].Points.AddXY(nm_4085, beta_4085);
                        break;
                    case 85:
                        chart1.Series["alpha(85)"].Points.AddXY(nm_4085, alpha_4085);
                        chart1.Series["beta(85)"].Points.AddXY(nm_4085, beta_4085);
                        break;
                }
            }

            double nm_65, alpha_65, beta_65 = 0;

            for (int i = 1; i < count2; i++)
            {
                nm_65 = Single.Parse(records65[i].wavelength);
                alpha_65 = Single.Parse(records65[i].alpha);
                beta_65 = Single.Parse(records65[i].beta);

                chart1.Series["alpha(측정)"].Points.AddXY(nm_65, alpha_65);
                chart1.Series["beta(측정)"].Points.AddXY(nm_65, beta_65);
            }
        }
    }
}
