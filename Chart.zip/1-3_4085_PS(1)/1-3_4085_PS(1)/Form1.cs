﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace _1_3_4085_PS_1_
{
    public partial class Form1 : Form
    {
        public class Data4085
        {
            public string wavelength { get; set; }
            public string AOI { get; set; }
            public string P { get; set; }
            public string S { get; set; }
        }

        int count1 = 0;
        List<Data4085> records4085 = new List<Data4085>();
        public Form1()
        {
            InitializeComponent();

            char[] replace = { ' ', ',', '\t', '\n' };
            string[] lines = File.ReadAllLines("C://Si_new_700_reflect.txt", Encoding.Default);

            foreach (var line in lines)
            {
                string[] splitData = line.Split(replace, StringSplitOptions.RemoveEmptyEntries);
                records4085.Add(new Data4085
                {
                    wavelength = splitData[0],
                    AOI = splitData[1],
                    P = splitData[2],
                    S = splitData[3]
                });
                count1++;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            chart1.Series.Clear();

            chart1.Series.Add("P 반사율");
            chart1.Series["P 반사율"].ChartType = SeriesChartType.Line;
            chart1.Series["P 반사율"].BorderWidth = 3;
            chart1.Series["P 반사율"].Color = Color.Red;

            chart1.Series.Add("S 반사율");
            chart1.Series["S 반사율"].ChartType = SeriesChartType.Line;
            chart1.Series["S 반사율"].BorderWidth = 3;
            chart1.Series["S 반사율"].Color = Color.Orange;

            double nm, P, S = 0;

            int aoi = 0;

            for (int i = 1; i < count1; i++)
            {
                nm = Single.Parse(records4085[i].wavelength);
                aoi = Convert.ToInt32(records4085[i].AOI);
                P = Single.Parse(records4085[i].P);
                S = Single.Parse(records4085[i].S);

                chart1.Series["P 반사율"].Points.AddXY(aoi, P);
                chart1.Series["S 반사율"].Points.AddXY(aoi, S);

                //switch (aoi)
                //{
                //    case 40:
                //        chart1.Series["P 반사율"].Points.AddXY(aoi, P);
                //        chart1.Series["S 반사율"].Points.AddXY(aoi, S);
                //        break;
                //    case 45:
                //        chart1.Series["P 반사율"].Points.AddXY(aoi, P);
                //        chart1.Series["S 반사율"].Points.AddXY(aoi, S);
                //        break;
                //    case 50:
                //        chart1.Series["P 반사율"].Points.AddXY(aoi, P);
                //        chart1.Series["S 반사율"].Points.AddXY(aoi, S);
                //        break;
                //    case 55:
                //        chart1.Series["P 반사율"].Points.AddXY(aoi, P);
                //        chart1.Series["S 반사율"].Points.AddXY(aoi, S);
                //        break;
                //    case 60:
                //        chart1.Series["P 반사율"].Points.AddXY(aoi, P);
                //        chart1.Series["S 반사율"].Points.AddXY(aoi, S);
                //        break;
                //    case 65:
                //        chart1.Series["P 반사율"].Points.AddXY(aoi, P);
                //        chart1.Series["S 반사율"].Points.AddXY(aoi, S);
                //        break;
                //    case 70:
                //        chart1.Series["P 반사율"].Points.AddXY(aoi, P);
                //        chart1.Series["S 반사율"].Points.AddXY(aoi, S);
                //        break;
                //    case 75:
                //        chart1.Series["P 반사율"].Points.AddXY(aoi, P);
                //        chart1.Series["S 반사율"].Points.AddXY(aoi, S);
                //        break;
                //    case 80:
                //        chart1.Series["P 반사율"].Points.AddXY(aoi, P);
                //        chart1.Series["S 반사율"].Points.AddXY(aoi, S);
                //        break;
                //    case 85:
                //        chart1.Series["P 반사율"].Points.AddXY(aoi, P);
                //        chart1.Series["S 반사율"].Points.AddXY(aoi, S);
                //        break;
                //}
            }
        }
    }
}